# accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/fruixs/pen/VwXaBMW](https://codepen.io/fruixs/pen/VwXaBMW).

