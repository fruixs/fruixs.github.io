# Keyboard accessible menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/superart/pen/zYGqayO](https://codepen.io/superart/pen/zYGqayO).

Shamelessly stolen from http://examples.simplyaccessible.com/css-menu/option-6.html