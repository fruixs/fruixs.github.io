/**
 * exports some default animation settings.
 */
export let animationDefaults = {
    duration: 0.7,
    ease: 'expo'
};