export const animationDefaults = {
    duration: 1.4,
    ease: 'power4'
};