/**
 * exports some default options.
 */
 export let menuConfig = {
    slotMachineTotalLetters: 8,
    displayVerticalTitle: 'HAPUKU'
};