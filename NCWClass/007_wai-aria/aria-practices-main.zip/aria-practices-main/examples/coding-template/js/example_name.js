/*
 * This content is licensed according to the W3C Software License at
 * https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document
 */

/*
 * Rename this file to the name of the example, e.g., checkbox.js.
 */
